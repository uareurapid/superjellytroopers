﻿using UnityEngine;
using System.Collections;
using RescueJelly;

public class MissionsScript : MonoBehaviour {

	public string[] scrollIntro;
	public float offset = 0;
	public float speed = 2.5f;
	public int mode = 2;
	public int scrollFontSize = 22;
	public Font scrollFont;
	public int lineHeight = 1;

	private GUIStyle centeredStyleLarger;
	
	private Texture2D exitTexture;
	private Rect exitTextureRect;


	public bool missionOneCompleted = false;
	public bool missionTwoCompleted = false;
	public bool missionThreeCompleted = false;
	public bool missionFourCompleted = false;
	//public bool missionFiveCompleted = false;


	private SpriteRenderer missionOne;
	private SpriteRenderer missionTwo;
	private SpriteRenderer missionThree;
	private SpriteRenderer missionFour;


	private static RuntimePlatform platform;
	bool isMobilePlatform = false;
	
	GUISkin skin;

	//We will not use game center for the missions (only for achievements and leaderboards)
	//missions could have been, but were not, designed on Game Center as achievements
	void Start () {
	
	    //add a delay because of the touches stored
		StartCoroutine(Wait(3));
		
		//Invoke("LoadNextScene",20); 
		//loads main screen after 20 seconds
		
		//make sure we are not stopped
		Time.timeScale = 1.0f; 
		skin = Resources.Load("GUISkin") as GUISkin;
		exitTexture = Resources.Load("menu") as Texture2D;
		missionFourCompleted=true;

		missionOne = GameObject.FindGameObjectWithTag("Mission1").GetComponent<SpriteRenderer>();
		missionTwo = GameObject.FindGameObjectWithTag("Mission2").GetComponent<SpriteRenderer>();
		missionThree = GameObject.FindGameObjectWithTag("Mission3").GetComponent<SpriteRenderer>();
		missionFour = GameObject.FindGameObjectWithTag("Mission4").GetComponent<SpriteRenderer>();

		//check the conquered missions
		CheckMissions();

		
	}
	//called before start
	void Awake() {
		
		GUIResolutionHelper.Instance.CheckScreenResolution();
		offset = GUIResolutionHelper.Instance.screenHeight + 200;
		isMobilePlatform = (platform == RuntimePlatform.IPhonePlayer || platform == RuntimePlatform.Android);
	}

	void CheckMissions() {
		
		missionOneCompleted = PlayerPrefs.GetInt(GameConstants.MISSION_1_KEY,0)>0;
	    missionTwoCompleted = PlayerPrefs.GetInt(GameConstants.MISSION_2_KEY,0)>0;
		missionThreeCompleted = PlayerPrefs.GetInt(GameConstants.MISSION_3_KEY,0)>0;
		missionFourCompleted = PlayerPrefs.GetInt(GameConstants.MISSION_4_KEY,0)>0;

		if(missionOneCompleted) {
		    missionOne.sprite = missionOne.gameObject.GetComponent<DoubleSpriteScript>().spriteEnabled;
		}
		else {
			missionOne.sprite = missionOne.gameObject.GetComponent<DoubleSpriteScript>().spriteDisabled;
		}
		    
		if(missionTwoCompleted) {
		    missionTwo.sprite = missionTwo.gameObject.GetComponent<DoubleSpriteScript>().spriteEnabled;
		}
		else {
			missionTwo.sprite = missionTwo.gameObject.GetComponent<DoubleSpriteScript>().spriteDisabled;
		}

		if(missionThreeCompleted) {
		    missionThree.sprite = missionThree.gameObject.GetComponent<DoubleSpriteScript>().spriteEnabled;
		}
		else {
			missionThree.sprite = missionThree.gameObject.GetComponent<DoubleSpriteScript>().spriteDisabled;
		}

		if(missionFourCompleted) {
		    missionFour.sprite = missionFour.gameObject.GetComponent<DoubleSpriteScript>().spriteEnabled;
		}
		else {
			missionFour.sprite = missionFour.gameObject.GetComponent<DoubleSpriteScript>().spriteDisabled;
		}

	}
	
	//delay to clear touches
	private IEnumerator Wait(long seconds)
		
	{
		
		yield return new WaitForSeconds(seconds);

		
	}
	
	void Update() {




		
	}
	
	
	void BuildLargerLabelStyle() {
	
		centeredStyleLarger = GUI.skin.GetStyle("Label");
		centeredStyleLarger.alignment = TextAnchor.MiddleLeft;
		centeredStyleLarger.font = scrollFont;
		centeredStyleLarger.fontSize = scrollFontSize;
	}
	
	
	// Update is called once per frame
	void OnGUI () {
	
	   GUI.skin = skin;

	//if(Event.current.type==EventType.Repaint) {
	
	    BuildLargerLabelStyle();
	
		
		Matrix4x4 svMat = GUI.matrix;//save current matrix
		
		bool isWideScreen = GUIResolutionHelper.Instance.isWidescreen;
		Vector3 scaleVector = GUIResolutionHelper.Instance.scaleVector;
		
		if(isWideScreen) {
			GUI.matrix = Matrix4x4.TRS(new Vector3( (GUIResolutionHelper.Instance.scaleX - scaleVector.y) / 2 * GUIResolutionHelper.Instance.screenWidth, 0, 0), Quaternion.identity, scaleVector);

		}
		else {
			GUI.matrix = Matrix4x4.TRS(Vector3.zero,Quaternion.identity,scaleVector);
			
		}
		
		//GUI.matrix = Matrix4x4.TRS(Vector3.zero,Quaternion.identity,GUIResolutionHelper.Instance.scaleVector);
	   		
		int width = GUIResolutionHelper.Instance.screenWidth; 
		int height = GUIResolutionHelper.Instance.screenHeight;
		
		//centeredStyleLarger.fontSize = 40;
		//GUI.Label(new Rect(width/2-170,125,600,60),"Super Jelly Troopers",centeredStyleLarger);
		
		//centeredStyleLarger.normal.textColor =  new Color32(223,168,43,255);
		//GUI.Label(new Rect(width/2-60,120,400,60),"Missions",centeredStyleLarger);
		
		//centeredStyleLarger.fontSize = 25;
		//GUI.Label(new Rect(width/3,height-190,500,50),"Copyright ©2014",centeredStyleLarger);		
		//GUI.Label(new Rect(width/3,height-140,500,50),"http://www.pcdreams-software.com",centeredStyleLarger);
		
		//reset color back to white
		centeredStyleLarger.normal.textColor =  Color.white;
		
		if (mode == 1){ 
			offset += Time.deltaTime * speed; 
		} 
		else if (mode == 2) { 
			offset -= Time.deltaTime * speed; 
		}


			int max = scrollIntro.Length-1;
			
			for (int i = max; i >=0 ; i--) {
				float roff = (scrollIntro.Length*-45) + (i*45 + offset);

				float alph = Mathf.Sin((roff/height)*180*Mathf.Deg2Rad);
				GUI.color = new Color(1,1,1, alph);

				GUI.Label(new Rect(width/2-250,roff,width-100, 70),scrollIntro[i],centeredStyleLarger);
				GUI.color = new Color(1,1,1,1);
			}
			
			//if we have scrolled all text, we move to next scene
			if (offset > height + 200) { 
				mode = 2;
			} else if (offset < -200) { 
				mode = 1;
			}
			
		
			if(Event.current.type==EventType.Repaint) {
			//menu button
				//if(isWideScreen) {
				//  exitTextureRect = new Rect(Screen.width - 100 * (GUIResolutionHelper.Instance.scaleX - scaleVector.y) / 2,20,96,96);
				//}
				//else {
				  exitTextureRect = new Rect(width-110,30,96,96);
				//}
			

				GUI.DrawTexture(exitTextureRect,exitTexture);

			}


		//mobile touches
		if(isMobilePlatform && Input.touchCount == 1 && exitTexture!=null)
		{
			Touch touch = Input.touches[0]; 
			Vector2 fingerPos = new Vector2(0,0);
			fingerPos = touch.position;
			
			fingerPos.y =  height - (touch.position.y / Screen.height) * height;
			fingerPos.x = (touch.position.x / Screen.width) * width;
			
			if(isWideScreen) {
				//do extra computation
				fingerPos.x = fingerPos.x + (GUIResolutionHelper.Instance.scaleX - GUIResolutionHelper.Instance.scaleVector.y) / 2 * width;
			}
			
			if(touch.phase == TouchPhase.Began)
				
			{
				// do amazing things
				if(exitTextureRect.Contains(fingerPos)) {
				  Application.LoadLevel("SettingsScene");
				}
				
			}
		}
		//desktop platform
		else if(!isMobilePlatform && Event.current.type == EventType.MouseUp ) {
				
			if(exitTextureRect.Contains(Event.current.mousePosition) ) {
				//show the game over when clicked the exit
				Application.LoadLevel("SettingsScene");
			}
		}

		//restor the matrix	
		GUI.matrix = svMat;
	  
				
		
	}
	
	
	
	//equivalent to menu
	private void LoadNextScene() {
		 
		Application.LoadLevel("StoreScene");
	}
	
	
}
